var myApp = require('express');
var app=myApp()
var mongooseApp = require('mongoose');
var myModel = require('./model/react_gmit');
var bodyPar = require('body-parser');
var myBodyParser=bodyPar.json();
var mycrypto=require('crypto');
var key="password";
var algo='aes256';
var jwt=require('jsonwebtoken');
var jwtkey='jwtkey';

mongooseApp.connect('mongodb+srv://suman12345:Suman12345@cluster0.yfzzi.mongodb.net/react?retryWrites=true&w=majority',{
    useNewUrlParser:true,
    useUnifiedTopology: true    
}).then(()=>{
    console.log("System Connectd")
});

app.post('/password',myBodyParser,function(req,res){
    myModel.findOne({email:req.body.Myemail}).then((data)=>{
        var decipher=mycrypto.createDecipher(algo,key);
        var decryptedPassword=decipher.update(data.password, 'hex','utf8')+
        decipher.final('utf8');
        if(decryptedPassword==req.body.password){
            jwt.sign({data},jwtkey,{expiresIn:'180s'},(err,token)=>{
                res.status(200).json({token})
            })
        }
        console.log("password Matched",data.password);
        
    })
   
   })

app.get('/getjwt',verifyToekn,function(req,res){
    myModel.find().then((result)=>{
        res.status(200).json(result)
    })
})

// creating verification token in middleware & apply the verify token in get function
function verifyToekn(req,res,next){
    const bearerHeader=req.headers['authorization'];
    console.log(bearerHeader);
    if(typeof bearerHeader !== 'undefined')
    {
        res.send("Its working")
    }
    else{
        res.send({"result":"Token Missing"})
    }
}

app.listen(4799)