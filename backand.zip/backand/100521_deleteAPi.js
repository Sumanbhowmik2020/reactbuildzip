var myApp = require('express');
var app=myApp();
var mongooseApp= require('mongoose');
var myModel=require('./model/react_gmit');
var bodyParser=require('body-parser');
var mybodyParsers=bodyParser.json();
mongooseApp.connect('mongodb+srv://suman12345:Suman12345@cluster0.yfzzi.mongodb.net/react?retryWrites=true&w=majority',
{useNewUrlParser: true,
    useUnifiedTopology: true,}

);
app.get('/userdata',function(req,res){
    myModel.find().then((details)=>{
        res.json(details)
    })
})


app.delete('/suman/:id',function(req,res){
    myModel.deleteOne({_id:req.params.id}).then((result)=>{
        res.status(200).json(result)
    })
    .catch(err=>console.log(err))

})

app.listen(4559)