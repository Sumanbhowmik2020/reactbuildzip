var expressRoute=require('express');
var expressApp=expressRoute();

var routeCheck=function(req, res, next)
{
    console.log("current url is", req.originalUrl)
    next();
}
expressApp.use(routeCheck);


expressApp.get('/home',function(req,res){
    res.send('Hello World GMIT');
});

expressApp.get('/suman',function(req,res){
    res.send('Hello suman');
});


expressApp.listen(4250);
