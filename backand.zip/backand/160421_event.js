var myevent =require('events');
var myEvent = new myevent.EventEmitter();

myEvent.on("working",function(student){
    console.warn(student," STudent working")
})

myEvent.emit("working","gmit's");