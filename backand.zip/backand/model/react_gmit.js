var mongooseUser=require('mongoose');
var userSchema= new mongooseUser.Schema({
  _id:mongooseUser.Schema.Types.ObjectId,
  name:String,
  email:String,
  mobile:String ,
  password:String 
});
module.exports=mongooseUser.model('react_gmits',userSchema)
