var expressRoute=require('express');
var expressApp=expressRoute();

var router=expressRoute.Router();

// var routeCheck=function(req, res, next)
// {
//     console.log("current url is", req.originalUrl)
//     next();
// }
//expressApp.use(routeCheck);


expressApp.get('/',function(req,res){
    res.sendFile(__dirname+'/home.html');
});

expressApp.get('/about', function(req,res){
    res.sendFile(__dirname+'/about.html');
});
expressApp.get('/contact', function(req,res){
    res.sendFile(__dirname+'/contact.html');
});

expressApp.use('/',router);


expressApp.listen(4550);
