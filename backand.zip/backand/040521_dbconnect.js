var expressApp = require('express');
var dataApp=expressApp();
var mongooseApp=require('mongoose');
var Users=require('./model/react_gmit');
mongooseApp.connect('mongodb+srv://suman12345:Suman12345@cluster0.yfzzi.mongodb.net/react?retryWrites=true&w=majority',
{useNewUrlParser: true,
    useUnifiedTopology: true,}

);

// Users.find({},function(err,Users){
//     if (err)console.warn(err);
//     console.warn(Users)
// }).catch(err=>console.log(err))

var info= new Users({
    _id:mongooseApp.Types.ObjectId(),
    name:"sudipon",
    email:"sudipon@gmail.com",
    mobile:"12345678"  ,
})
info.save().then((result)=>{
    console.log(result);
}).catch(err=>console.log(err))