const {render}=require('ejs');
var expressRoute=require('express');
var expressApp=expressRoute();
expressApp.use('/assets/css',expressRoute.static('assets/css'))

expressApp.set('view engine','ejs');


// var routeCheck=function(req, res, next)
// {
//     console.log("current url is", req.originalUrl)
//     next();
// }
//expressApp.use(routeCheck);


expressApp.get('/',function(req,res){
    // Details={mobile:'9876543210',Sex:'Male',language:['english','bengali','hindi']};
    // // console.log(req.params.email)


    res.render('home.ejs');
});
expressApp.get('/test/:email',function(req,res){
    Details={mobile:'9876543210',Sex:'Male',language:['english','bengali','hindi']};
    // console.log(req.params.email)


    res.render('test.ejs',{email:req.params.email,Details:Details});
});


expressApp.get('/contact.ejs',function(req,res){
    
    // console.log(req.params.email)


    res.render('contact.ejs');
});

expressApp.get('/profile.ejs',function(req,res){
    
    // console.log(req.params.email)


    res.render('profile.ejs');
});




expressApp.listen(4200);
