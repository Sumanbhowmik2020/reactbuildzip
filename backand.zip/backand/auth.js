var expApp = require('express');
var myApp = expApp();
var mongooseApp = require('mongoose');
var myModel = require('./model/react_gmit');
var bodyPar = require('body-parser');
var myBodyParser=bodyPar.json();
var myCrypto=require('crypto');
var jwt=require('jsonwebtoken');
var jwtkey='jwtkey';

var key="password";
var algo="aes256";

mongooseApp.connect('mongodb+srv://suman12345:Suman12345@cluster0.yfzzi.mongodb.net/react?retryWrites=true&w=majority',{
    useNewUrlParser:true,
    useUnifiedTopology: true    
}).then(()=>{
    console.log("Connected")
});

myApp.post('/postjwt',myBodyParser,function(req,res){
    myModel.findOne({email:req.body.Myemail}).then((data)=>{
        var deCypher= myCrypto.createDecipher(algo,key);
        var decryptPass = deCypher.update(data.password,'hex', 'utf-8')
        +deCypher.final('utf-8');
        if(decryptPass==req.body.password){
            jwt.sign({data},jwtkey,{expiresIn:'180s'},(err,token)=>{
                res.status(201).json({token})
            })
        }
        console.log("Password Matched ",data.password);
    })
})


myApp.get('/getjwt',verifyToken,function(req,res){
    myModel.find().then((result)=>{
        res.status(200).json(result)
    })
})

//Creating verification token in middleware & apply the verifytoken in get function

function verifyToken(req,res,next){
    const bHeader =req.headers['authorization'];
    if(typeof bHeader !== 'undefined'){
        const bToken=bHeader.split(' ');
        console.log(bToken[1]);
        req.token=bToken[1];
        jwt.verify(req.token, jwtkey,(err,authData)=>{
            if(err){
                res.json({result:err})
            }
            else{
                next();
            }
        })
    }
    else {
        res.send({"result":"Token Missing"})
    }
}
myApp.listen(4500);

// eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7Il9pZCI6IjYwOWFlMDJlYmJiODVjMGM1MGEzZTdlNyIsImVtYWlsIjoiYWJpckBnbWFpbC5jb20iLCJwYXNzd29yZCI6IjhhZTMxZDYxMWJlNjBlZDIyM2I5ODBjN2FiNWIwN2YzIiwiX192IjowfSwiaWF0IjoxNjIxMDIyNTgwLCJleHAiOjE2MjEwMjI3NjB9.HF7XTuqB1tVgoYVlyKSCJoo7GeJGJ9ChYFJgn0QeCQk
// {
//     "myEmail":"abir@gmail.com",
//     "password":"abir123"
// }