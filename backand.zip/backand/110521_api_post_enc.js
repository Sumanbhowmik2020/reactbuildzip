var myApp = require('express');
var app=myApp()
var mongooseApp = require('mongoose');
var myModel = require('./model/react_gmit');
var bodyPar = require('body-parser');
var myBodyParser=bodyPar.json();
var mycrypto=require('crypto');
var key="password";
var algo='aes256';

mongooseApp.connect('mongodb+srv://suman12345:Suman12345@cluster0.yfzzi.mongodb.net/react?retryWrites=true&w=majority',{
    useNewUrlParser:true,
    useUnifiedTopology: true    
});


app.post('/postenc',myBodyParser,function(req,res){
    var myCipher=mycrypto.createCipher(algo,key);
    var encryptedPassword=myCipher.update(req.body.password,'utf8','hex')
    +myCipher.final('hex');

    console.log(req.body,encryptedPassword);

    res.end(encryptedPassword);
})

app.listen(4799)

