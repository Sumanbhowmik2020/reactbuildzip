var expressRoute=require('express');
var expressApp=expressRoute();

expressApp.set('view engine','ejs');


// var routeCheck=function(req, res, next)
// {
//     console.log("current url is", req.originalUrl)
//     next();
// }
//expressApp.use(routeCheck);


expressApp.get('/home/:email',function(req,res){
    console.log(req.params.email)
    res.render('home.ejs',{email:req.params.email});
});

// expressApp.get('/about', function(req,res){
//     res.sendFile(__dirname+'/about.html');
// });
// expressApp.get('/contact', function(req,res){
//     res.sendFile(__dirname+'/contact.html');
// });

// expressApp.use('/',router);


expressApp.listen(4550);
