var express = require('express');
var app = express();

app.post('/gmit', function (req, res) {
   res.send('Hello World GMIT');
});
app.post('/mit', function (req, res) {
   res.send('Hello World MIT');
});
app.post('/it', function (req, res) {
   res.send('Hello World IT');
});

app.listen(4400);