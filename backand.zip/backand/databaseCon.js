var mySql=require('mysql');
var  connection =mySql.createConnection({

    host  :'localhost',
    user  :'root',
    password :'',
    database :'react_db'

});

connection.connect(function(error){
if(error) throw error;
connection.query("SELECT * FROM db",function(errr,result)
{
    if(errr) throw errr;
    console.log("hii the data are",result)
} )
});