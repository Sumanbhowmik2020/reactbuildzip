var myApp = require('express');
var app=myApp()
var mongooseApp = require('mongoose');
var myModel = require('./model/react_gmit');
var bodyPar = require('body-parser');
var myBodyParser=bodyPar.json();

mongooseApp.connect('mongodb+srv://suman12345:Suman12345@cluster0.yfzzi.mongodb.net/react?retryWrites=true&w=majority',{
    useNewUrlParser:true,
    useUnifiedTopology: true    
});


app.get('/regex/:name',function(req,res){
    const myregex = new RegExp(req.params.name,'i');
    myModel.find({name:myregex}).then((result)=>{
        res.status(200).json(result)
    })
    .catch(err=>console.log(err))

})

app.listen(4799)

