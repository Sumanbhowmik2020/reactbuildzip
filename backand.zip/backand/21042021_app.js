const {render} = require('ejs');
var expRoute=require('express');
var expApp=expRoute();
expApp.use('/assets/css',expRoute.static('assets/css'));
expApp.set('view engine','ejs');

var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'react_db'
});
 


expApp.get('/profile/:email',function(req,res){
    details={mobile:'2015',Sex:'m',lang:['eng','beng','hindi']}
    res.render('profile',{email:req.params.email,detail:details});
});
expApp.get('/',function(req,res){
    res.render('home');
});
expApp.get('/about',function(req,res){

    connection.query("SELECT * FROM userdata",function(err,result){
        if(err) throw err;
        res.render('about',{result:result});
    });
    
});

expApp.listen(4500);