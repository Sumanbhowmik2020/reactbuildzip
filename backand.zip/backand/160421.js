var event= require('fs');
var event_rs=event.createReadStream('./testevent.txt');
event_rs.on('open',function (){
    console.warn("ACTIVE")
})