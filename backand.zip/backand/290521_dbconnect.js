var myApp = require('express');
var app=myApp();
app.use(myApp.json());
var mongooseApp = require('mongoose');
var myModel=require('./model/react_gmit');
var mycrypto=require('crypto');
var key="password";
var algo='aes256';
var jwt=require('jsonwebtoken');
var jwtkey='jwtkey';


mongooseApp.connect('mongodb+srv://suman12345:Suman12345@cluster0.yfzzi.mongodb.net/react?retryWrites=true&w=majority',
    {useNewUrlParser : true,
    useUnifiedTopology : true}
);


// //for signup
// app.post('/newsignup',function(req,res){
//   let {email, mobile, password} = req.body;

//     const data=new myModel({
//       _id:new mongooseApp.Types.ObjectId(),
//       email,mobile,password

//   });
//   data.save().then((result)=>{
//       res.status(201).json(result)
//   })
//   .catch(err=>console.log(err))

// })




// //for signup using encrypted password
app.post('/newsignup',function(req,res){

    let {email, mobile, password} = req.body;
    var myCipher= mycrypto.createCipher(algo,key);

    // encrypt the password Advanced Encryption Standard 256 using UTF8 & hex 
    var encpassword=myCipher.update(password,'utf8','hex')
    +myCipher.final('hex');

    const newdata=new myModel({
        _id: mongooseApp.Types.ObjectId(),
        email,mobile,password:encpassword
    });
    newdata.save().then((result)=>{
        res.status(201).json(result)
    })

    .catch(err=>console.log(err))

})



//for login using encrypted password
app.post('/newlogin', function (req, res) {
    
    let {email, password} = req.body;
    myModel.findOne({email}).then((data) => {
       
        var decipher = mycrypto.createDecipher(algo, key);
        var decryptedPassword = decipher.update(data.password, 'hex', 'utf8' )+ 
        decipher.final('utf8');
        console.log(decryptedPassword);
        if(decryptedPassword==password){
            jwt.sign({data},jwtkey,{expiresIn:'180s'},(err,result)=>{
                res.status(200).json({result})
            })
            console.log("Password Matched ");
        }
        else
        {
            console.log("not valid");
        } 
    });
})




app.listen(4500,()=>{
console.log("server is running on port 4500");
})