var uC=require('upper-case')
var http = require('http');
var testData='hi'
//create a server object:
http.createServer(function (req, res) {
  // res.write('Hello World!');
  // res.writeHead()
   //write a response to the client
    res.writeHead(200,{'Content-Type':"text/html"})
  res.write(uC.upperCase(testData));
  res.end(); //end the response
}).listen(4500); //the server object listens on port 8080